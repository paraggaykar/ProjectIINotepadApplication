package com.notepadapplication6.notepadapplication6;

/**
 * Created by trident on 7/7/16.
 */
public class ShoppingContents {

    private int shpid;
    private String shpitem;

    public ShoppingContents() {
    }

    public ShoppingContents(int shpid, String shpitem) {
        this.shpid = shpid;
        this.shpitem = shpitem;
    }

    public ShoppingContents(String shpitem) {
        this.shpitem = shpitem;
    }

    public ShoppingContents(int id) {
    }

    public int getShpid() {
        return shpid;
    }

    public void setShpid(int shpid) {
        this.shpid = shpid;
    }

    public String getShpitem() {
        return shpitem;
    }

    public void setShpitem(String shpitem) {
        this.shpitem = shpitem;
    }

    @Override
    public String toString() {
        return "ShoppingContents{" +
                "shpid=" + shpid +
                ", shpitem='" + shpitem + '\'' +
                '}';
    }
}

package com.notepadapplication6.notepadapplication6;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by trident on 6/7/16.
 */
public class ToDoActivity extends ListActivity implements AdapterView.OnItemClickListener {

    AGSQLiteHelper db = new AGSQLiteHelper(this);
    List<ToDOContents> list;
    ArrayAdapter<String> myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.todo_layout);

        final EditText task = (EditText) findViewById(R.id.taskEdit);
        final Button addTask = (Button) findViewById(R.id.addTask);

        taskList();


        addTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String tasktodo = task.getText().toString();

                db.insertTask(new ToDOContents(tasktodo));

                Context context = getApplicationContext();
                CharSequence text = "Record inserted";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();

                task.setText("");

                db.close();

                taskList();



            }

         });

    }




    public void taskList() {
        list = db.getAllTasks();



        List<String> listTitle = new ArrayList<String>();

        for (int i = 0; i < list.size(); i++) {
            listTitle.add(i, list.get(i).getTodotitle());


        }



        myAdapter = new ArrayAdapter<String>(this, R.layout.taskrow_layout, R.id.listText, listTitle);
        getListView().setOnItemClickListener(this);
        setListAdapter(myAdapter);



    }



    public void changeStatus(final View view) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure,You wanted to change task status to done?");

        alertDialogBuilder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

                View view1 = (View) view.getParent();

                TextView ltask = (TextView) view1.findViewById(R.id.listText);
                String task1 = String.valueOf(ltask.getText());

                db.updateTaskStatus(new ToDOContents(task1));
                db.close();
                taskList();

                db.showStatus(task1);
                String tskstatus = db.showStatus(task1);




                if(tskstatus.equals("Done")) {
                    CheckBox status = (CheckBox) view1.findViewById(R.id.task_check);
                    status.setChecked(true);

                  /*  Context context = getApplicationContext();
                    //CharSequence text = "Record inserted";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, tskstatus, duration);
                    toast.show(); */
                }

            }
        });

        alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                taskList();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();



        /*
       // boolean checked = ((CheckBox) view).isChecked();
        CheckBox checkBox = (CheckBox)view.findViewById(R.id.task_check);
        if(checkBox.isChecked()){
            View view1 = (View) view.getParent();
            TextView ltask = (TextView) view1.findViewById(R.id.listText);
            String task1 = String.valueOf(ltask.getText());

            db.updateTaskStatus(new ToDOContents(task1));
            db.close();
            taskList();
        } */

    }

    public void deleteTask(final View view) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure,You wanted to delete this task?");

        alertDialogBuilder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

                View view1 = (View) view.getParent();
                TextView ltask = (TextView) view1.findViewById(R.id.listText);
                String task1 = String.valueOf(ltask.getText());

                db.deleteTask(new ToDOContents(task1));
                db.close();
                taskList();

            }
        });

        alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                taskList();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();

    }


  /*  public void displayStatus(View view){
        View view1 = (View) view.getParent();
        TextView ltask = (TextView) view1.findViewById(R.id.listText);
        String task1 = String.valueOf(ltask.getText());

        db.showStatus(task1);
        String tsktsatus = db.showStatus(task1);
        if(tsktsatus == "Done");
        status.setChecked(true);
    }
    */





    @Override
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        list = db.getAllTasks();

        List<String> listTitle = new ArrayList<String>();

        for (int i = 0; i < list.size(); i++) {
            listTitle.add(i, list.get(i).getTodotitle());

        }



        myAdapter = new ArrayAdapter<String>(this, R.layout.taskrow_layout, R.id.listText, listTitle);
        getListView().setOnItemClickListener(this);
        setListAdapter(myAdapter);

    }



}

package com.notepadapplication6.notepadapplication6;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 * Created by trident on 14/7/16.
 */
public class MemosActivity extends Activity {

    EditText filename,filedata;
    Button savaData,clear,showMemos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo_layout);

        filename = (EditText) findViewById(R.id.fileName);
        filedata = (EditText) findViewById(R.id.fileData);
        savaData = (Button) findViewById(R.id.save);
        clear = (Button) findViewById(R.id.clear);
        showMemos = (Button) findViewById(R.id.showmemos);

        savaData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fname = filename.getText().toString();
                String fdata = filedata.getText().toString();

                FileOutputStream fos;

                try{
                    File myFile = new File("/sdcard/"+fname);
                    myFile.createNewFile();
                    FileOutputStream fOut = new

                            FileOutputStream(myFile);
                    OutputStreamWriter myOutWriter = new

                            OutputStreamWriter(fOut);
                    myOutWriter.append(fdata);
                    myOutWriter.close();
                    fOut.close();

                    Toast.makeText(getApplicationContext(),fname + " saved",Toast.LENGTH_LONG).show();


                } catch (FileNotFoundException e) {e.printStackTrace();}
                catch (IOException e) {e.printStackTrace();}



            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filename.setText("");
                filedata.setText("");
            }
        });

        showMemos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MemosScrollViewActivity.class);
                startActivity(i);
            }
        });


    }
}

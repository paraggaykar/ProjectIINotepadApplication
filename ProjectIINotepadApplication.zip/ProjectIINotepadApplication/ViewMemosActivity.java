package com.notepadapplication6.notepadapplication6;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by trident on 14/7/16.
 */
public class ViewMemosActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.displayselectedmemo);

       EditText fileContent = (EditText) findViewById(R.id.fileContents);
        EditText fileName = (EditText) findViewById(R.id.fileName);
        Button back = (Button) findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MemosScrollViewActivity.class);
                startActivity(i);
            }
        });

        Intent intent = getIntent();
        String fname = intent.getStringExtra("path");



        StringBuffer stringBuffer = new StringBuffer();
        String aDataRow = "";
        String aBuffer = "";
        try {
            File myFile = new File("/sdcard/"+fname);
            FileInputStream fIn = new FileInputStream(myFile);
            BufferedReader myReader = new BufferedReader(new InputStreamReader(fIn));

            while ((aDataRow = myReader.readLine()) != null) {
                aBuffer += aDataRow + "\n";
            }
            myReader.close();


        } catch (IOException e){
            e.printStackTrace();
        }
        //Toast.makeText(getApplicationContext(),aBuffer,Toast.LENGTH_LONG).show();
        fileName.setText(fname);
        fileContent.setText(aBuffer);



/*
        Context context = getApplicationContext();
        //CharSequence text = "Record inserted";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, fname, duration);
        toast.show();
*/
    }
}

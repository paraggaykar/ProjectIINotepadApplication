package com.notepadapplication6.notepadapplication6;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by trident on 5/7/16.
 */
public class UpdateDeleteNotes extends Activity {

    TextView tittle,notes;
    EditText ettitttle,etnotes;
    NotepadContents selectedNotes;
    AGSQLiteHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.updatedelete_notes);

        tittle = (TextView) findViewById(R.id.tv_tittle);
        notes = (TextView) findViewById(R.id.tv_notes);

        ettitttle = (EditText) findViewById(R.id.tittleEdit);
        etnotes = (EditText) findViewById(R.id.noteEdit);

        Intent intent = getIntent();
        final int id = intent.getIntExtra("ID",-1);

        db = new AGSQLiteHelper(getApplicationContext());

        selectedNotes = db.readNotes(id);

        initializeViews();

    }

    public  void initializeViews(){
        tittle.setText(selectedNotes.getTittle());
        notes.setText(selectedNotes.getNotes());
        ettitttle.setText(selectedNotes.getTittle());
        etnotes.setText(selectedNotes.getNotes());
    }

    public void update(View v){
        Toast.makeText(getApplicationContext(),"This note is updated",Toast.LENGTH_SHORT).show();

        selectedNotes.setTittle(((EditText) findViewById(R.id.tittleEdit)).getText().toString());
        selectedNotes.setNotes(((EditText) findViewById(R.id.noteEdit)).getText().toString());

        db.updateNotes(selectedNotes);
        finish();
    }

    public void delete(View v){
        Toast.makeText(getApplicationContext(),"This note is deleted",Toast.LENGTH_SHORT).show();

        db.deleteNote(selectedNotes);
        finish();
    }
}

package com.notepadapplication6.notepadapplication6;

/**
 * Created by trident on 6/7/16.
 */
public class ToDOContents {

    private int todoid;
    private String todotitle;

    public ToDOContents(int todoid, String todotitle) {
        this.todoid = todoid;
        this.todotitle = todotitle;
    }

    public ToDOContents(String todotitle) {
        this.todotitle = todotitle;
    }

    public ToDOContents() {
    }

    public int getTodoid() {
        return todoid;
    }

    public void setTodoid(int todoid) {
        this.todoid = todoid;
    }

    public String getTodotitle() {
        return todotitle;
    }

    public void setTodotitle(String todotitle) {
        this.todotitle = todotitle;
    }

    @Override
    public String toString() {
        return "ToDOContents{" +
                "todoid=" + todoid +
                ", todotitle='" + todotitle + '\'' +
                '}';
    }
}

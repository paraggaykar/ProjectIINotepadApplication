package com.notepadapplication6.notepadapplication6;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by trident on 5/7/16.
 */
public class CreatenotesActivity extends Activity {

    AGSQLiteHelper db = new AGSQLiteHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_notes);

        final EditText tittle = (EditText) findViewById(R.id.create_title_edittext);
        final EditText notes = (EditText) findViewById(R.id.create_note_edittext);

        final Button create = (Button) findViewById(R.id.create);
        final Button clear = (Button) findViewById(R.id.clear);
        final Button show = (Button) findViewById(R.id.shownotes);

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ttl = tittle.getText().toString();
                String not = notes.getText().toString();

                db.insertValues(new NotepadContents(ttl,not));

                Context context = getApplicationContext();
                CharSequence text = "Record inserted";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();

                db.close();

            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tittle.setText("");
                notes.setText("");
            }
        });

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ViewnotesActivity.class);
                startActivity(i);
            }
        });

    }
}

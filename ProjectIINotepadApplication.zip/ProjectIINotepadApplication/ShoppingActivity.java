package com.notepadapplication6.notepadapplication6;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by trident on 7/7/16.
 */
public class ShoppingActivity extends ListActivity implements AdapterView.OnItemClickListener {

    AGSQLiteHelper db = new AGSQLiteHelper(this);
    List<ShoppingContents> list;
    ArrayAdapter<String> myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shopping_layout);





        final EditText item = (EditText) findViewById(R.id.itemEdit);
        final Button addItem = (Button) findViewById(R.id.addItem);

        itemList();

        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String shpitem = item.getText().toString();

                db.insertShoppingItem(new ShoppingContents(shpitem));

                Context context = getApplicationContext();
                CharSequence text = "Record inserted";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();

                item.setText("");
                db.close();
                itemList();
            }
        });


    }



    public void changeStatus(final View view) {



        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure,You wanted to change item status to done?");

        alertDialogBuilder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

                View view1 = (View) view.getParent();
                TextView ltask = (TextView) view1.findViewById(R.id.listText);
                CheckBox status = (CheckBox) view1.findViewById(R.id.item_check);
                String task1 = String.valueOf(ltask.getText());

                db.updateItemStatus(new ShoppingContents(task1));
                db.close();
                itemList();

                db.showItemStatus(task1);
                String itemStatus = db.showItemStatus(task1);

                Context context = getApplicationContext();
                //CharSequence text = "Record inserted";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, itemStatus, duration);
                toast.show();


                if(itemStatus.equals("Done")) {
                    status.setChecked(true);
                }

            }
        });

        alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                itemList();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();

      /*  View view1 = (View) view.getParent();
            TextView item = (TextView)view1.findViewById(R.id.listText);

            String item1 = String.valueOf(item.getText());

            db.updateItemStatus(new ShoppingContents(item1));
            db.close();
            itemList();
        */

    }




    public void itemList() {
        list = db.getAllItems();

        List<String> listTitle = new ArrayList<String>();

        for (int i = 0; i < list.size(); i++) {
            listTitle.add(i, list.get(i).getShpitem());



        }

        myAdapter = new ArrayAdapter<String>(this, R.layout.shoppingrow_layout, R.id.listText, listTitle);
        getListView().setOnItemClickListener(this);
        setListAdapter(myAdapter);


    }

   /* public void displayStatus(View view){
        View view1 = (View) view.getParent();
        TextView ltask = (TextView) view1.findViewById(R.id.listText);
        String task1 = String.valueOf(ltask.getText());

        db.showItemStatus(task1);
        String tsktsatus = db.showStatus(task1);
        if(tsktsatus == "Done");
        status.setChecked(true);
    } */



    public void deleteItem(final View view) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure,You wanted to delete this item?");

        alertDialogBuilder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

                View view1 = (View) view.getParent();
                TextView ltask = (TextView) view1.findViewById(R.id.listText);
                String task1 = String.valueOf(ltask.getText());

                db.deleteItem(new ShoppingContents(task1));
                db.close();
                itemList();

            }
        });

        alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                itemList();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();

    }


    @Override
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {





    }


    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
/*
        String i = list.get(position).getShpitem();

        db.updateItemStatus(new ShoppingContents(i));
        db.close();
        itemList();
        */

    }
}

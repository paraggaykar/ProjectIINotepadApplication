package com.notepadapplication6.notepadapplication6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

/**
 * Created by trident on 5/7/16.
 */
public class AGSQLiteHelper extends SQLiteOpenHelper {

    private static final int database_VERSION = 1;
    // database name
    private static final String database_NAME = "Notepad";
    private static final String table_NOTEPAD = "notepad";
    private static final String COL_ID = "id";
    private static final String COL_TITTLE = "tittle";
    private static final String COL_NOTE = "note";
    private static final String COL_DATE = "date";

    private static final String table_TODO = "todolist";
    private static final String TODO_ID = "taskid";
    private static final String TODO_TITLE = "tasktittle";
    private static final String TODO_DATE = "taskdate";
    private static final String TODO_STATUS = "taskstatus";

    private static final String table_SHOPPING = "shoppinglist";
    private static final String SHOP_ID = "itemid";
    private static final String SHOP_ITEM = "item";
    private static final String SHOP_DATE = "purchasedate";
    private static final String SHOP_STATUS = "status";

    private static final String[] COLUMNS = {COL_ID, COL_TITTLE, COL_NOTE, COL_DATE};

    private static final String[] TODO_COLUMNS = {TODO_ID, TODO_TITLE, TODO_DATE, TODO_STATUS};

    private static final String[] SHOP_COLUMNS = {SHOP_ID, SHOP_ITEM, SHOP_DATE, SHOP_STATUS};

    public AGSQLiteHelper(Context context) {
        super(context, database_NAME, null, database_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_NOTEPAD_TABLE = "CREATE TABLE notepad ( " + "id INTEGER PRIMARY KEY AUTOINCREMENT, " + "tittle TEXT, " + "note TEXT, " + "date TEXT)";
        db.execSQL(CREATE_NOTEPAD_TABLE);

        String CREATE_TODO_TABLE = "CREATE TABLE todolist ( " + "taskid INTEGER PRIMARY KEY AUTOINCREMENT, " + "tasktittle TEXT, " + "taskdate TEXT, " + "taskstatus TEXT)";
        db.execSQL(CREATE_TODO_TABLE);

        String CREATE_SHOP_TABLE = "CREATE TABLE shoppinglist ( " + "itemid INTEGER PRIMARY KEY AUTOINCREMENT, " + "item TEXT, " + "purchasedate TEXT, " + "status TEXT)";
        db.execSQL(CREATE_SHOP_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop books table if already exists
        db.execSQL("DROP TABLE IF EXISTS notepad");
        db.execSQL("DROP TABLE IF EXISTS todolist");
        db.execSQL("DROP TABLE IF EXISTS shoppinglist");
        this.onCreate(db);
    }

    private String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }

    public void insertValues(NotepadContents notepadContents) {

        SQLiteDatabase db = this.getWritableDatabase();

        // make values to be inserted
        ContentValues values = new ContentValues();
        values.put(COL_TITTLE, notepadContents.getTittle());
        values.put(COL_NOTE, notepadContents.getNotes());
        values.put(COL_DATE, getDateTime());


        db.insert(table_NOTEPAD, null, values);

        db.close();

    }

    public void insertTask(ToDOContents toDOContents) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(TODO_TITLE, toDOContents.getTodotitle());
        values.put(TODO_DATE, getDateTime());
        values.put(TODO_STATUS, "Remaining");

        db.insert(table_TODO, null, values);

        db.close();
    }

    public void insertShoppingItem(ShoppingContents shoppingContents) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(SHOP_ITEM, shoppingContents.getShpitem());
        values.put(SHOP_DATE, getDateTime());
        values.put(SHOP_STATUS, "Reamaining");

        db.insert(table_SHOPPING, null,values);

        db.close();
    }

    public List<NotepadContents> getAllTitles() {
        List<NotepadContents> notepadContentsList = new LinkedList<>();

        String query = "SELECT * FROM notepad ORDER BY date DESC";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query,null);

        NotepadContents notepadContents = null;
        if ((cursor.moveToFirst())){
            do {
                notepadContents = new NotepadContents();
                notepadContents.setId(Integer.parseInt(cursor.getString(0)));
                notepadContents.setTittle(cursor.getString(1));
                notepadContents.setNotes(cursor.getString(2));

                notepadContentsList.add(notepadContents);
            } while (cursor.moveToNext());
        }

        return notepadContentsList;
    }

    public List<NotepadContents> getSingleNote(String title) {

        List<NotepadContents> notepadContentsList = new LinkedList<>();
        SQLiteDatabase db = this.getWritableDatabase();



        Cursor cursor = db.query(table_NOTEPAD, null,"tittle LIKE '%"+title+"%'",null, null, null, null);





        NotepadContents notepadContents = null;
        if((cursor.moveToFirst())){
            do{
                notepadContents = new NotepadContents();
                notepadContents.setId(Integer.parseInt(cursor.getString(0)));
                notepadContents.setTittle(cursor.getString(1));
                notepadContents.setNotes(cursor.getString(2));

                notepadContentsList.add(notepadContents);
            } while (cursor.moveToNext());
        }

        return notepadContentsList;
    }

    public List<ToDOContents> getAllTasks() {
        List<ToDOContents> toDOContentsList = new LinkedList<>();

        String query = "SELECT * FROM todolist";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query,null);

        ToDOContents toDOContents = null;
        if((cursor.moveToFirst())){
            do {
                toDOContents = new ToDOContents();
                toDOContents.setTodoid(Integer.parseInt(cursor.getString(0)));
                toDOContents.setTodotitle(cursor.getString(1));

                toDOContentsList.add(toDOContents);
            } while (cursor.moveToNext());
        }

        return toDOContentsList;
    }

    public List<ShoppingContents> getAllItems() {
        List<ShoppingContents> shoppingContentsList = new LinkedList<>();

        String query = "SELECT * FROM shoppinglist ORDER BY purchasedate DESC";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query,null);

        ShoppingContents shoppingContents = null;
        if((cursor.moveToFirst())) {
            do {
                shoppingContents = new ShoppingContents();
                shoppingContents.setShpid(Integer.parseInt(cursor.getString(0)));
                shoppingContents.setShpitem(cursor.getString(1));

                shoppingContentsList.add(shoppingContents);
            } while (cursor.moveToNext());
        }

        return shoppingContentsList;
    }

    public NotepadContents readNotes(int id)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(table_NOTEPAD,COLUMNS, " id = ? ", new String[] { String.valueOf(id) } , null, null, null, null);



        if(cursor != null)
            cursor.moveToFirst();

        NotepadContents notepadContents = new NotepadContents();
        notepadContents.setId(Integer.parseInt(cursor.getString(0)));
        notepadContents.setTittle(cursor.getString(1));
        notepadContents.setNotes(cursor.getString(2));

        return notepadContents;
    }

    public String showStatus(String title){

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(table_TODO,TODO_COLUMNS, " tasktittle = ? ", new String[] { String.valueOf(title) } , null, null, null, null);

        if(cursor != null)
            cursor.moveToFirst();


        String st = cursor.getString(3);



        return st;

    }

    public String showItemStatus(String title){

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(table_SHOPPING,SHOP_COLUMNS, " item = ? ", new String[] { String.valueOf(title) } , null, null, null, null);

        if(cursor != null)
            cursor.moveToFirst();

        String st1 = cursor.getString(3);

        return st1;

    }


    public int updateNotes(NotepadContents notepadContents){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("tittle",notepadContents.getTittle());
        values.put("note",notepadContents.getNotes());

        int i = db.update(table_NOTEPAD, values, COL_ID +" =?", new String[] { String.valueOf(notepadContents.getId())});
        db.close();
        return i;
    }

    public void deleteNote(NotepadContents notepadContents) {

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(table_NOTEPAD, COL_ID +" =?", new String[] { String.valueOf(notepadContents.getId())});
        db.close();
    }

    public int updateTaskStatus(ToDOContents toDOContents) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("taskstatus", "Done");

        int task = db.update(table_TODO, values, TODO_TITLE +" =?", new String[] { String.valueOf(toDOContents.getTodotitle())});
        db.close();
        return task;

    }

    public int updateItemStatus(ShoppingContents shoppingContents) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("status", "Done");;

        int item = db.update(table_SHOPPING, values, SHOP_ITEM +" =?", new String[] {String.valueOf(shoppingContents.getShpitem())});
        db.close();
        return item;
    }

    public void deleteTask(ToDOContents toDOContents) {

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(table_TODO, TODO_TITLE +" =?", new String[] { String.valueOf(toDOContents.getTodotitle())});
        db.close();
    }

    public void deleteItem(ShoppingContents shoppingContents) {

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(table_SHOPPING, SHOP_ITEM +" =?", new String[] { String.valueOf(shoppingContents.getShpitem())});
        db.close();
    }


}

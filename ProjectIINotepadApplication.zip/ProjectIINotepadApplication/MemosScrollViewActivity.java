package com.notepadapplication6.notepadapplication6;

import java.io.File;
import java.lang.reflect.Array;
import java.util.ArrayList;
import com.notepadapplication6.notepadapplication6.R;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MemosScrollViewActivity extends Activity {

    private File root;
    private ArrayList<File> fileList = new ArrayList<File>();
    private LinearLayout view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scrollviewofmemos);

        view = (LinearLayout) findViewById(R.id.view);

        //getting SDcard root path
        root = new File(Environment.getExternalStorageDirectory()
                .getAbsolutePath());
        getfile(root);





        for (int i = 0; i < fileList.size(); i++) {
            TextView textView = new TextView(this);
            textView.setText(fileList.get(i).getName());
            textView.setPadding(15, 15, 15, 15);
            textView.setTextColor(Color.parseColor("#FF0000"));
            textView.setTextAppearance(android.R.style.TextAppearance_Large);

           // File file = new File(fileList.get(i).getName());


            //System.out.println(fileList.get(i).getName());

            /*if (fileList.get(i).isDirectory()) {
                textView.setTextColor(Color.parseColor("#FF0000"));
            }*/
            view.addView(textView);

        }

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Intent i = new Intent(getApplicationContext(), ViewMemosActivity.class);
               // startActivity(i);



               for (int j = 0; j < fileList.size(); j++){
                    String filename = fileList.get(j).getName();

                    Intent intent = new Intent(getApplicationContext(), ViewMemosActivity.class);
                    intent.putExtra("path",filename);
                    startActivity(intent);


                }









            }
        });


    }

    public ArrayList<File> getfile(File dir) {
        File listFile[] = dir.listFiles();
        if (listFile != null && listFile.length > 0) {
            for (int i = 0; i < listFile.length; i++) {

                /*if (listFile[i].isDirectory()) {
                    fileList.add(listFile[i]);
                    getfile(listFile[i]);

                } else { */
                    if (listFile[i].getName().endsWith(".txt"))


                    {
                        fileList.add(listFile[i]);




                    }


               // }

            }
        }
        return fileList;
    }


}







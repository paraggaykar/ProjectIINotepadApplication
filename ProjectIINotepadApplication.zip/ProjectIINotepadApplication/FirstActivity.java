package com.notepadapplication6.notepadapplication6;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by trident on 6/7/16.
 */
public class FirstActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_layout);

        final TextView DNotes = (TextView) findViewById(R.id.notes);
        final TextView DTodo = (TextView) findViewById(R.id.todolist);
        final TextView DShopping = (TextView) findViewById(R.id.shoppinglist);
        final TextView DMemos = (TextView) findViewById(R.id.memos);

        DNotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), CreatenotesActivity.class);
                startActivity(i);
            }
        });

        DTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ToDoActivity.class);
                startActivity(i);
            }
        });

        DShopping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ShoppingActivity.class);
                startActivity(i);
            }
        });

        DMemos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MemosActivity.class);
                startActivity(i);
            }
        });

    }
}

package com.notepadapplication6.notepadapplication6;

/**
 * Created by trident on 5/7/16.
 */
public class NotepadContents {

    private int id;
    private String tittle,notes;

    public NotepadContents(int id, String tittle, String notes) {
        this.id = id;
        this.tittle = tittle;
        this.notes = notes;
    }

    public NotepadContents() {

    }

    public NotepadContents(String tittle, String notes) {
        this.tittle = tittle;
        this.notes = notes;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTittle() {
        return tittle;
    }

    public void setTittle(String tittle) {
        this.tittle = tittle;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }


    @Override
    public String toString() {
        return "NotepadContents{" +
                "id=" + id +
                ", tittle='" + tittle + '\'' +
                ", notes='" + notes + '\'' +
                '}';
    }
}
